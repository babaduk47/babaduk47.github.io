<?php
$_ = array (
  'heading_title' => 'Google Sitemap',
  'text_feed' => 'Каналы продвижения',
  'text_success' => 'Настройки модуля обновлены!',
  'text_edit' => 'Редактирование',
  'entry_status' => 'Статус',
  'entry_data_feed' => 'Адрес',
  'error_permission' => 'У Вас нет прав для управления этим модулем!',
);
