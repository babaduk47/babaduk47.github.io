<?php
$_ = array (
  'heading_title' => 'Люди Online',
  'text_view' => 'подробнее...',
);
