<?php
$_ = array (
  'heading_title' => 'OpenBay Pro',
  'text_module' => 'Modules',
  'text_installed' => 'OpenBay Pro module is now installed. It is available under Extensions -> OpenBay Pro',
);
