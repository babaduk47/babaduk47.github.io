<?php
$_ = array (
  'heading_title' => 'Сброс пароля',
  'text_reset' => 'Сброс пароля!',
  'text_password' => 'Введите новый пароль!',
  'text_success' => 'Ваш пароль успешно обновлен!',
  'entry_password' => 'Пароль',
  'entry_confirm' => 'Подтвердите пароль',
  'error_password' => 'Пароль должен составлять от 5 до 20 символов!',
  'error_confirm' => 'Пароли не совпадают!',
);
