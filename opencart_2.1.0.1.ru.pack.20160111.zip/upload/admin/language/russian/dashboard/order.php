<?php
$_ = array (
  'heading_title' => 'Заказов',
  'text_view' => 'подробнее...',
);
