<?php
$_ = array (
  'heading_title' => 'Аналитика продаж',
  'text_order' => 'Заказов',
  'text_customer' => 'Клиентов',
  'text_day' => 'Сегодня',
  'text_week' => 'Неделя',
  'text_month' => 'Месяц',
  'text_year' => 'Год',
);
