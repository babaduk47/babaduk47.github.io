<?php
$_ = array (
  'heading_title' => 'Карта мира',
  'text_order' => 'Заказов',
  'text_sale' => 'Продаж',
);
