<?php
$_ = array (
  'heading_title' => 'Авторизация',
  'text_heading' => 'Авторизация',
  'text_login' => 'Введите логин и пароль',
  'text_forgotten' => 'Забыли пароль?',
  'entry_username' => 'Логин',
  'entry_password' => 'Пароль',
  'button_login' => 'Войти',
  'error_login' => 'Такой логин и/или пароль не существует!',
  'error_token' => 'Неправильная токен-сессия. Авторизуйтесь снова.',
);
