<?php
// Heading
$_['heading_title'] = 'Dashboard';

// Error
$_['error_install'] = 'Warning: Install folder still exists and should be deleted for security reasons!';