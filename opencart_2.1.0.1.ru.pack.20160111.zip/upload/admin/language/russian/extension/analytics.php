<?php
// Heading
$_['heading_title']    = 'Аналитика';

// Text
$_['text_success']     = 'Успех: Вы изменили аналитики!';
$_['text_list']        = 'Список Аналитики';

// Column
$_['column_name']      = 'Аналитика Имя';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Активность';

// Error
$_['error_permission'] = 'Внимание: Вы не имеете разрешения на изменения аналитику!';
