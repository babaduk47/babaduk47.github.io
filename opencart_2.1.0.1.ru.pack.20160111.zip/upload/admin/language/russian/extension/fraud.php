<?php
// Heading
$_['heading_title']    = 'Анти-Мошенничество';

// Text
$_['text_success']     = 'Успех: Вы изменили Анти-Мошенничество!';
$_['text_list']        = 'Анти-Мошеннический Лист';

// Column
$_['column_name']      = 'Имя';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Активность';

// Error
$_['error_permission'] = 'Внимание: Вы не имеете разрешения на изменения Анти-Мошенничество!';