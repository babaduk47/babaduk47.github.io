<?php
$_ = array (
  'heading_title' => 'Доставка',
  'text_success' => 'Настройки успешно обновлены!',
  'text_list' => 'Список способов доставки',
  'column_name' => 'Способ доставки',
  'column_status' => 'Статус',
  'column_sort_order' => 'Порядок сортировки',
  'column_action' => 'Действие',
  'error_permission' => 'У Вас нет прав для управления доставкой!',
);
