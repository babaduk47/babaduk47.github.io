<?php
$_ = array (
  'heading_title' => 'Оплата',
  'text_success' => 'Настройки успешно обновлены!',
  'text_list' => 'Список способов оплаты',
  'column_name' => 'Способ оплаты',
  'column_status' => 'Статус',
  'column_sort_order' => 'Порядок сортировки',
  'column_action' => 'Действие',
  'error_permission' => 'У Вас нет прав для управления модулем Оплата!',
);
