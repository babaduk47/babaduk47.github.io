<?php
$_ = array (
  'heading_title' => 'Продаж',
  'text_view' => 'подробнее...',
);
