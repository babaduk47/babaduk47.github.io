<?php
$_ = array (
  'text_footer' => 'Данная сборка подготовлена командой <a href="http://www.opencart.ru">opencart.ru</a>',
  'text_version' => 'Версия %s',
);
