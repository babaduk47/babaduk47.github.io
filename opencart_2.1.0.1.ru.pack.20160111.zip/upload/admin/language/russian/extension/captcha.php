<?php
// Heading
$_['heading_title']    = 'Captcha';

// Text
$_['text_success']     = 'Успех: Вы изменили Captcha!';
$_['text_list']        = 'Список Captcha';

// Column
$_['column_name']      = 'Captcha Имя';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Активность';

// Error
$_['error_permission'] = 'Внимание: Вы не имеете разрешения на изменения captchas!';
