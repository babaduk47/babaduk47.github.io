<?php
$_ = array (
  'heading_title' => 'Последнии заказы',
  'column_order_id' => '№',
  'column_customer' => 'Покупатель',
  'column_status' => 'Состояние',
  'column_total' => 'Сумма',
  'column_date_added' => 'Добавлено',
  'column_action' => 'Действие',
);
