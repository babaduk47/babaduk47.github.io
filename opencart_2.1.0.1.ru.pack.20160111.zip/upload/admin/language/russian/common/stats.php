<?php
$_ = array (
  'text_complete_status' => 'Завершенных заказов',
  'text_processing_status' => 'Заказов в процессе',
  'text_other_status' => 'Другие заказы',
);
