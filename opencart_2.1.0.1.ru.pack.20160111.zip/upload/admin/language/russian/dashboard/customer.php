<?php
$_ = array (
  'heading_title' => ' Клиентов',
  'text_view' => 'подробнее...',
);
