<?php
$_ = array (
  'heading_title' => 'Каналы продвижения',
  'text_success' => 'Настройки успешно обновлены!',
  'text_list' => 'Список каналов',
  'column_name' => 'Название канала',
  'column_status' => 'Статус',
  'column_action' => 'Действие',
  'error_permission' => 'У Вас нет прав для изменения канала товаров!',
);
