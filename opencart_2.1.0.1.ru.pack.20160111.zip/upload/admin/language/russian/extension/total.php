<?php
$_ = array (
  'heading_title' => 'Учитывать в заказе',
  'text_success' => 'Настройки успешно обновлены!',
  'text_list' => 'Учитывать в заказе',
  'column_name' => 'Учитывать в заказе',
  'column_status' => 'Статус',
  'column_sort_order' => 'Порядок сортировки',
  'column_action' => 'Действие',
  'error_permission' => 'У Вас нет прав для управления этим модулем!',
);
