<?php
$_ = array (
  'heading_title' => 'Google Base',
  'text_feed' => 'Каналы продвижения',
  'text_success' => 'Настройки модуля обновлены!',
  'text_list' => 'Google Base',
  'text_edit' => 'Edit Google Base',
  'entry_status' => 'Статус',
  'entry_data_feed' => 'URL канала',
  'error_permission' => 'У Вас нет прав для управления этим модулем!',
);
